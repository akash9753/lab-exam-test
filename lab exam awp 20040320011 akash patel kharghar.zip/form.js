function commenthere(){
    let usercomment = document.querySelector("#inputid1").Value;
    const newelement = document.querySelector("#referencecommentid").cloneNode(true);

    newelement.removeAttribute("id");
    newelement.style.visibility = "visible";
    newelement.children[0].innerHTML = usercomment;


    const commentbox = document.querySelector("#commentbox");

    commentbox.insertBefore(newelement,commentbox.firstChild);

    document.querySelector("#inputid1").Value="";
}
function commenthere2(){
    let usercomment = document.querySelector("#inputid2").Value;
    const newelement = document.querySelector("#referencecommentid2").cloneNode(true);

    newelement.removeAttribute("id");
    newelement.style.visibility = "visible";
    newelement.children[0].innerHTML = usercomment;


    const commentbox2 = document.querySelector("#commentbox2");

    commentbox2.insertBefore(newelement,commentbox2.firstChild);

    document.querySelector("#inputid2").Value="";
}

function commenthere3(){
    let usercomment = document.querySelector("#inputid3").Value;
    const newelement3 = document.querySelector("#referencecommentid3").cloneNode(true);

    newelement3.removeAttribute("id");
    newelement3.style.visibility = "visible";
    newelement3.children[0].innerHTML = usercomment;


    const commentbox3 = document.querySelector("#commentbox3");

    commentbox3.insertBefore(newelement3,commentbox3.firstChild);

    document.querySelector("#inputid3").Value="";
}
